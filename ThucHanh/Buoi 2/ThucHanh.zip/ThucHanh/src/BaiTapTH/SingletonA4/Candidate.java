package BaiTapTH.SingletonA4;

enum Candidate {
  Trump,
  Biden
}
