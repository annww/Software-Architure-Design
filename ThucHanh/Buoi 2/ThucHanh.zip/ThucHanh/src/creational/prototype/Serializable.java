package creational.prototype;

public interface Serializable {
}
