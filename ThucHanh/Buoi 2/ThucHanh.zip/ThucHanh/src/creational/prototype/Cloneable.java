package creational.prototype;

public interface Cloneable {
}
