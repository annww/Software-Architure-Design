package creational.composite;

abstract class KeHoachHT {
  String ten;
  public abstract void add(KeHoachHT k);
  public abstract void remove(KeHoachHT k);
  public abstract int getsoTC();
  public abstract int gethocPhi();
  public abstract String thongTin();

}


