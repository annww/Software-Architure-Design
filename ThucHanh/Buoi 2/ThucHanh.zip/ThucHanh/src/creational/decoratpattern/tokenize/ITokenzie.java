package creational.decoratpattern.tokenize;

import java.util.List;

public interface ITokenzie {
  List<String> tokenzie();
}
