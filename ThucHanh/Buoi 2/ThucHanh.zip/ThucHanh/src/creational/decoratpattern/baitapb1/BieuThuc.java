package creational.decoratpattern.baitapb1;

public abstract class BieuThuc {
  public abstract float giaTri();
  public abstract String bieuThuc();

}
