package OnThi.nontification;

public class MainClass {
  public static void main(String[] args) {
    GuiThongBao noteP = new LocalNontification();
    noteP.guiThongBao();
  }
}
