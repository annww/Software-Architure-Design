package OnThi.nontification;

public abstract class Nontification {
  public String tieuDe, noiDung;
  public int doUuTien, logo;

  abstract void taoThongBao();
  abstract void guiThongBao();
  abstract void duaThongBao();
}
