package behavioral.observerpattern.baiCA5;

public interface TaiKhoanATM {
  boolean kiemTraSoDu(int soTien);

  void nhanThongBao(int soTienRut, boolean thanhCong);
}
