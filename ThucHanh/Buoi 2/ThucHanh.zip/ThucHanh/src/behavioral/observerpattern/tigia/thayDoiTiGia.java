package behavioral.observerpattern.tigia;

public interface thayDoiTiGia {
  public void Update(float delta);

}
