package factorymethod;

public enum ShapeType {
  rectangle,triangle, circle
}
